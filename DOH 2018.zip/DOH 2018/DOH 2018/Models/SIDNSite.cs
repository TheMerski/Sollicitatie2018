﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DOH_2018.Models
{
    /// <summary>
    /// Model of the SIDN site information
    /// </summary>
    public class SIDNSite
    {
        /// <summary>
        /// Domain name of the site
        /// </summary>
        public string DomainName { get; set; }
        /// <summary>
        /// Ip adress of the site
        /// </summary>
        public string IpAdress { get; set; }
        /// <summary>
        /// NameServer of the site 
        /// </summary>
        public List<string> NameServer { get; set; }


        public SIDNSite()
        {
            NameServer = new List<string>();
        }
    }
}
