﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DOH_2018.Models
{
    /// <summary>
    /// Class for the Suspicious sites from the police 
    /// </summary>
    public class SuspiciousSite
    {
        /// <summary>
        /// String for the Url of suspicious sites
        /// </summary>
        public string DomainName { get; set; }

        /// <summary>
        /// The reason for suspicion
        /// </summary>
        public string Reason { get; set; }

    }
}
