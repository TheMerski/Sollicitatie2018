﻿using System.Collections.Generic;

namespace DOH_2018.Models
{
    public class FlaggedSite
    {

        public int ID { get; set; }
        /// <summary>
        /// Domain name of the site
        /// </summary>
        public string DomainName { get; set; }
        /// <summary>
        /// Ip adress of the site
        /// </summary>
        public string IpAdress { get; set; }
        /// <summary>
        /// NameServer of the site 
        /// </summary>
        public List<string> NameServer { get; set; }

        public FlagStatus Status;
        public enum FlagStatus
        {
            Nieuw,
            Onderzoek,
            Confirmed,
            Geescaleerd,
            FalsePositive
        }

        public FlaggedSite(FlagStatus status)
        {
            NameServer = new List<string>();
            Status = status;
        }
    }
}