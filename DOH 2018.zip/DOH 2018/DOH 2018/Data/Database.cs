﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Microsoft.Data.Sqlite;

namespace DOH_2018
{
    public class Database
    {
        private SqlClientFactory _factory = SqlClientFactory.Instance;
        private SqliteConnection _conn;

        public Database()
        {
            _conn = new SqliteConnection("Data Source=database.sqlite;");
        }

        public void CommitTransaction(string query)
        {
            SqliteCommand command = _conn.CreateCommand();
            command.CommandText = query;
            command.ExecuteNonQuery();
            command.Dispose();
        }

        public void CreateDatabase()
        {
            CommitTransaction("CREATE TABLE IF NOT EXIST badsites(one varchar(10), two smallint);");
        }
    }
}
