﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DOH_2018.Models;
using Microsoft.ApplicationInsights.Extensibility.Implementation;
using Microsoft.AspNetCore.Server.Kestrel.Core.Internal.Infrastructure;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace DOH_2018.Controllers
{
    public class HomeController : Controller
    {
        private static HttpClient _httpClient = new HttpClient();
        private Database database = new Database();
        /// <summary>
        /// Location of the JSON file containing suspicious sites
        /// </summary>
        private string _suspiciousSiteJson = "Data/SuspiciousSites.json";

        private string _SIDNstring = "http://dohdatasciencevm0.westeurope.cloudapp.azure.com/request/domain/";
        private string _NSstring = "http://dohdatasciencevm0.westeurope.cloudapp.azure.com/request/ns/";

        public IActionResult Index()
        {          
            string urls = "";
            foreach (SuspiciousSite Site in GetSuspiciousSites(_suspiciousSiteJson))
            {
                urls += Site.DomainName + '\n';
            }
            ViewData["SearchResults"] = new List<SIDNSite>();
            ViewData["NameServerLength"] = 0;

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public async Task<IActionResult> GetDomain(string domain)
        {
            string searchUrl = _SIDNstring + "\"" + domain + "\"";
            await DownloadSIDNresult(searchUrl);
            return View("Domain");
        }

        [HttpGet]
        public  IActionResult Domain(string domain)
        {
            GetDomain(domain);
            return View("Domain");
        }

        [HttpGet]
        public async Task<IActionResult> Search(string search)
        {
            string searchUrl = _SIDNstring + search;
            await DownloadSIDNresult(searchUrl);
            return View("Index");
        }

        [HttpPost]
        public async Task<IActionResult> SearchNS(string nsSearch)  
        {
            string tablessnsSearch = nsSearch.Replace("\t", "");
            string searchUrl = _NSstring + tablessnsSearch;
            await DownloadSNresult(searchUrl);
            return View("Domain");
        }


        /// <summary>
        /// Method to Parse a json file with SuspiciousSites to SuspiciousSite objects
        /// </summary>
        /// <param name="json">string of the json file containing Suspicious Sites</param>
        /// <returns>List of SuspiciousSite objects</returns>
        private List<SuspiciousSite> GetSuspiciousSites(string json)
        {
            List<SuspiciousSite> suspiciousSites =
                JsonConvert.DeserializeObject<List<SuspiciousSite>>(System.IO.File.ReadAllText(json));
            return suspiciousSites;
        }

        private void GetSIDNSearchResults(string searchResult)
        {
            List<SIDNSite> sites = new List<SIDNSite>();
            int nameServerLength = 0;
            string[] lines = searchResult.Split(new[] {"\r\n", "\r", "\n"}, StringSplitOptions.RemoveEmptyEntries);
            foreach (string line in lines)
            {
                line.Remove('\t');
                string[] splitLine = line.Split("NS", StringSplitOptions.RemoveEmptyEntries);
                SIDNSite site = new SIDNSite {DomainName = splitLine[0]};
                if (splitLine.Length > nameServerLength)
                {
                    nameServerLength = splitLine.Length;
                }
                for (int i = 1; i < splitLine.Length; i++)
                {
                    Console.WriteLine(splitLine[i]);
                    site.NameServer.Add(splitLine[i]);
                }
                sites.Add(site);
            }

            ViewData["NameServerLength"] = nameServerLength;
            ViewData["SearchResults"] = sites;
            ViewData["NS0"] = sites[0].NameServer[0];
            ViewData["Domain0"] = sites[0].DomainName;
        }

        private async Task DownloadSIDNresult(string search)
        {
            Console.WriteLine("Starting connection");
            var result = _httpClient.GetAsync(search).Result;
            GetSIDNSearchResults(result.Content.ReadAsStringAsync().Result);
        }

        private async Task DownloadSNresult(string search)
        {
            Console.WriteLine("Starting connection");
            var result = _httpClient.GetAsync(search).Result;
            string data = await result.Content.ReadAsStringAsync();
            GetNSSearchResults(data);
        }


        private void GetNSSearchResults(string searchResult)
        {
            if (searchResult.Equals("te veel"))
            {
                ViewData["FlaggedSites"] = "Too many";
            }
            else if (searchResult.Contains('<'))
            {
                ViewData["FlaggedSites"] = null;
            }
            else
            {
                List<FlaggedSite> sites = new List<FlaggedSite>();
                int FlaggednameServerLength = 0;
                string[] lines = searchResult.Split('\n');
                int counter = 0;
                foreach (string line in lines)
                {
                    counter++;
                    string[] splitLine = line.Split("NS", StringSplitOptions.RemoveEmptyEntries);
                    FlaggedSite site = new FlaggedSite(FlaggedSite.FlagStatus.Nieuw) { DomainName = splitLine[0] };
                    if (splitLine.Length > FlaggednameServerLength)
                    {
                        FlaggednameServerLength = splitLine.Length;
                    }
                    for (int i = 1; i < splitLine.Length; i++)
                    {
                        Console.WriteLine(splitLine[i]);
                        site.NameServer.Add(splitLine[i]);
                    }
                    sites.Add(site);
                }

                Console.WriteLine("test");
                ViewData["FlaggedSites"] = sites;
            }
        }

        private void InsertFlaggedSite(FlaggedSite FlaggedSite)
        {
            string query = "INSERT INTO badsites(one) VALUES" + FlaggedSite.DomainName;

            try
            {
                database.CommitTransaction(query);
            }
            catch
            {

            }
        }
    }
}
